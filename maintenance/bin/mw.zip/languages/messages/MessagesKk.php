<?php
/**
  * Kazakh (Қазақша)
  *
  * @addtogroup Language
  */

$fallback = 'kk-kz';

$linkTrail = '/^([a-zäçéğıïñöşüýа-яёәғіқңөұүһʺʹ“»]+)(.*)$/sDu';


