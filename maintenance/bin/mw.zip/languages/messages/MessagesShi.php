<?php

// Tachelhit

$fallback = 'fr'; // Is this an appropriate fallback?
