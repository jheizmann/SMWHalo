<?php
/** Fulah (Fulfulde)
 *
 * @addtogroup Language
 */

$fallback='fr';
