<?php
/**
 * Ewe (Eʋegbe)
 *
 * @addtogroup Language
 * Translators (from Betawiki):
 * @author Natsubee
 */

$messages = array(
# Dates
'january'   => 'Dzove',
'february'  => 'Dzodze',
'march'     => 'Tedoxe',
'april'     => 'Afɔfiɛ',
'may_long'  => 'Damɛ',
'june'      => 'Masa',
'july'      => 'Siamlɔm',
'august'    => 'Dasiamime',
'september' => 'Anyɔnyɔ',
'october'   => 'Kele',
'november'  => 'Adeɛmekpɔxe',
'december'  => 'Dzome',
'may'       => 'Damɛ',

);
