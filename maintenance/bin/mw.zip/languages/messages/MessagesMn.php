<?php
/**
 * Монгол (Mongoloian)
 *
 * @addtogroup Language
 *
 */

$linkTrail = '/^([a-zабвгдеёжзийклмнопрстуфхцчшщъыьэюя“»]+)(.*)$/sDu';
