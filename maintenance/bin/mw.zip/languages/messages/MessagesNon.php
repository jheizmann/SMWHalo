<?php
/** Old Norse (Norrǿna)
  *
  * Defaults to Icelandic instead of English.
  *
  * @addtogroup Language
  */
$fallback = 'is';


