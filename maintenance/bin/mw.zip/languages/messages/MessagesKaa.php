<?php
/**
 * Karakalpak (Qaraqalpaqsha)
 *
 * @addtogroup Language
 */

$linkTrail = '/^([a-zʻ`]+)(.*)$/sDu';


