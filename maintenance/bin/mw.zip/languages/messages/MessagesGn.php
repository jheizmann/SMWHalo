<?php
/** Guaraní (avañe'ẽ)
  *
  * @addtogroup Language
  */

$fallback = 'es';

