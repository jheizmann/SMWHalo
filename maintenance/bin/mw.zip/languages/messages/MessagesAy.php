<?php
/** Aymara
  *
  * @addtogroup Language
  */

$fallback = 'es';

