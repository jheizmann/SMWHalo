<?php
/**
  * Kurdish (latin)
  *
  * @addtogroup Language
  */

$fallback = 'ku-latn';


