<?php

$rtl = true;


